This is a chatroom appliction writen in python.
To Use:
	*Run pyhton ChatServer.py on the desired host
	*Client application takes two parameters
	*Run python ChatScreen.py hostIP Username
	*If username is taken please try a different username
	*To send a message fill the bottom left field with the message and press enter
	*To send a Direct message, put the username that you want to send it to in the feild above 
		message. Be sure to write a message and press enter.
	*To disconnect press the disconnect button
